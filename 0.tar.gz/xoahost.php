<?php
require_once __DIR__."/Client/include/config/database.php"; 
$xoa = $_GET['xoa'];
$phat = array(
                                    'ipwhm' => '',
                                    'tkwhm' => '',
                                    'mkwhm' => ''
                                    );
    $row = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `lsmuahost` WHERE = `id` = '$xoa'"));
$query = 'https://'.$phat['ipwhm'].':2087/json-api/removeacct?user='.$row['taikhoan'].''; 
                                $curl = curl_init(); // Create Curl Object 
                                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); // Allow self-signed certs 
                                curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0); // Allow certs that do not match the hostname 
                                curl_setopt($curl, CURLOPT_HEADER,0); // Do not include header in output 
                                curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
                                $header[0] = "Authorization: Basic " . base64_encode($phat['tkwhm'].":".$phat['mkwhm']) . "\n\r";
                                curl_setopt($curl, CURLOPT_HTTPHEADER, $header); // set the username and password 
                                curl_setopt($curl, CURLOPT_URL, $query); // execute the query 
                                $result = curl_exec($curl); 
                                $result = curl_exec($curl);
                                if ($result == false) {
                                    error_log("curl_exec threw error \"" . curl_error($curl) . "\" for $query");  
                                }
                                curl_close($curl);
mysqli_query($connect, "update `lsmuahost` set `trangthai` = '2' WHERE id = '".$xoa."'  ") or exit;
 die("<script>
    window.alert('Xóa host thành công!');
    window.location.href='/quan-ly-host?id=".$xoa."';
	</script>");
	exit;
?>