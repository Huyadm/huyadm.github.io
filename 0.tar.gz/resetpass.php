<?php
require_once __DIR__."/Client/include/config/database.php";
$id = $_GET['datlaimk'];
                                    $phatdz = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `lsmuahost` WHERE `id` = '$id'"));
                                    $phat = array(
                                    'ipwhm' => '',
                                    'tkwhm' => '',
                                    'mkwhm' => ''
                                    );
                                        $time = time();
                                $random_01 = rand(1,9);
                                $random_02 = rand(22,88);
                                $tenmk = "phat";
                                
                                $matkhau = $tenmk.$random_01.$random_02.$time; // mật khẩu của host cần reset pass
                                $mkrandom = rand(1111111111,9999999999);
                                $mkresetpass = "lB++-bI_(IWW";
                                $query = 'https://'.$phat['ipwhm'].':2087/json-api/passwd?api.version=1&user='.$phatdz['taikhoan'].'&password='.$matkhau.'&enabledigest=0&db_pass_update=1'; 
                                $curl = curl_init(); // Create Curl Object 
                                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); // Allow self-signed certs 
                                curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0); // Allow certs that do not match the hostname 
                                curl_setopt($curl, CURLOPT_HEADER,0); // Do not include header in output 
                                curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
                                $header[0] = "Authorization: Basic " . base64_encode($phat['tkwhm'].":".$phat['mkwhm']) . "\n\r";
                                curl_setopt($curl, CURLOPT_HTTPHEADER, $header); // set the username and password 
                                curl_setopt($curl, CURLOPT_URL, $query); // execute the query 
                                $result = curl_exec($curl); 
                                
                                if ($result == false) {
                                    error_log("curl_exec threw error \"" . curl_error($curl) . "\" for $query");  
                                }
                                curl_close($curl);
                                
                                mysqli_query($connect, "UPDATE lsmuahost SET `matkhau` = '$matkhau' WHERE `id` = '$id'");
                                ?>
                                <script>
                                window.location="/quan-ly-host?id=<?=$id;?>";
                                </script>
