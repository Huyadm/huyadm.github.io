-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th9 15, 2022 lúc 06:40 PM
-- Phiên bản máy phục vụ: 10.3.36-MariaDB-log-cll-lve
-- Phiên bản PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `btshxuct_abc`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danhmuc`
--

CREATE TABLE `danhmuc` (
  `id` bigint(20) NOT NULL,
  `ten` varchar(100) NOT NULL,
  `mota` varchar(100) NOT NULL,
  `thumbnail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `danhmuc`
--

INSERT INTO `danhmuc` (`id`, `ten`, `mota`, `thumbnail`) VALUES
(1, 'Shop Bán Acc', 'Source code shop bán nick game online', 'https://shopgaobac.com/tep-tin/1.gif'),
(2, '123213', '123123', 'https://www.upsieutoc.com/images/2020/10/27/demo03.png');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danhmuc1`
--

CREATE TABLE `danhmuc1` (
  `id` int(11) NOT NULL,
  `ten` varchar(100) NOT NULL,
  `mota` varchar(100) NOT NULL,
  `thumbnail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `danhmuc1`
--

INSERT INTO `danhmuc1` (`id`, `ten`, `mota`, `thumbnail`) VALUES
(1, 'Shop Bán Acc', 'Source code shop bán nick game online', 'https://accgame24h.vn/anh/1%20(3)%20(1).jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danhsachcode`
--

CREATE TABLE `danhsachcode` (
  `id` bigint(20) NOT NULL,
  `id_danhmuc` bigint(20) NOT NULL,
  `ten` varchar(100) NOT NULL,
  `mota` varchar(100) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  `gia` bigint(20) NOT NULL,
  `demo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `danhsachcode`
--

INSERT INTO `danhsachcode` (`id`, `id_danhmuc`, `ten`, `mota`, `thumbnail`, `gia`, `demo`) VALUES
(1, 1, 'SHOP BÁN ACC GIAO DIỆN CỰC VIP GIÁ RẺ', 'Chỉ Được Đặt Miền .tk .cf .gq .ml , còn miền .com .net liên hệ admin', 'https://upanh.cf/kgp13f62wk.png', 119000, 'https://taoshopgame.site'),
(2, 1, 'WEBSITE DVFB ĐẸP GIÁ RẺ ', 'Chỉ Được Đặt Miền .tk .cf .gq .ml , còn miền .com .net liên hệ admin', 'https://i.imgur.com/OmKuQ5b.jpg', 120000, 'https://taoshopgame.site'),
(3, 1, 'SHOP BÁN ACC  BẢN TẾT GIAO DIỆN ĐẸP', 'Chỉ Được Đặt Miền .tk .cf .gq .ml , còn miền .com .net liên hệ admin', 'https://i.imgur.com/3llDmwV.jpg', 115000, 'https://taoshopgame.site'),
(4, 1, 'SHOP BÁN ACC GIAO DIỆN ĐẸP GIÁ RẺ CỰC VIP', 'Chỉ Được Đặt Miền .tk .cf .gq .ml , còn miền .com .net liên hệ admin', 'https://upanh.cf/jb2vb1vvk0.jpg', 100000, 'https://taoshopgame.site'),
(5, 1, 'WEBSITE BÁN HOST VÀ MIỀN AUTO CỰC VIP', 'Chỉ Được Đặt Miền .tk .cf .gq .ml , còn miền .com .net liên hệ admin', 'https://i.imgur.com/QbzmcSY.jpg', 110000, 'https://taoshopgame.site'),
(6, 1, 'SHOP BÁN ACC LIÊN QUÂN , GIAO DIỆN ĐẸP , NẠP THẺ AUTO', 'Chỉ Được Đặt Miền .tk .cf .gq .ml , còn miền .com .net liên hệ admin', 'https://i.imgur.com/cQQvcOi.jpg', 100000, 'https://taoshopgame.site'),
(7, 1, 'SHOP BÁN ACC GIAO DIỆN ĐẸP GIÁ RẺ CỰC VIP', ' Chỉ Được Đặt Miền .tk .cf .gq .ml , còn miền .com .net liên hệ admin', 'https://upanh.cf/i0m6d3mbuc.jpg', 100000, 'https://upanh.cf/i0m6d3mbuc.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `goihost`
--

CREATE TABLE `goihost` (
  `id` int(11) NOT NULL,
  `cp_goi` varchar(999) NOT NULL,
  `tengoi` varchar(999) NOT NULL,
  `gia` int(11) NOT NULL,
  `disk` varchar(999) NOT NULL,
  `bangthong` varchar(999) NOT NULL,
  `addon` varchar(999) NOT NULL,
  `bidanh` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `goihost`
--

INSERT INTO `goihost` (`id`, `cp_goi`, `tengoi`, `gia`, `disk`, `bangthong`, `addon`, `bidanh`) VALUES
(1, 'tkwhm_goi1', 'VN1', 10000, '600', 'không giới hạn', 'không giới hạn', 'không giới hạn'),
(2, 'tkwhm_goi1', 'VN2', 10000, '600', 'không giới hạn', 'không giới hạn', 'không giới hạn');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoatdong`
--

CREATE TABLE `hoatdong` (
  `id` bigint(20) NOT NULL,
  `taikhoan` varchar(1000) NOT NULL,
  `hoatdong` varchar(1000) NOT NULL,
  `time` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lsmuahost`
--

CREATE TABLE `lsmuahost` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `email` varchar(32) NOT NULL,
  `tenmien` varchar(50) NOT NULL,
  `goi` varchar(999) NOT NULL,
  `taikhoan` varchar(32) NOT NULL,
  `matkhau` varchar(32) NOT NULL,
  `sotien` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `timehetdate` int(11) NOT NULL,
  `trangthai` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `magiamgia`
--

CREATE TABLE `magiamgia` (
  `id` bigint(20) NOT NULL,
  `magiamgia` varchar(100) NOT NULL,
  `phantram_giamgia` bigint(20) NOT NULL,
  `loai` varchar(100) NOT NULL,
  `trangthai` varchar(100) NOT NULL,
  `luotdung` bigint(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `muathe`
--

CREATE TABLE `muathe` (
  `id` bigint(20) NOT NULL,
  `uid` int(255) NOT NULL,
  `mathe` varchar(255) NOT NULL,
  `seri` varchar(100) NOT NULL,
  `menhgia` varchar(100) NOT NULL,
  `loaithe` varchar(100) NOT NULL,
  `trangthai` int(12) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `muathe`
--

INSERT INTO `muathe` (`id`, `uid`, `mathe`, `seri`, `menhgia`, `loaithe`, `trangthai`, `time`) VALUES
(123, 12, '44444444444444', '53543555555555', '100000', 'VINAPHONE', 2, '19/05/2022 - 19:40:09'),
(124, 12, 'Đang Truy Xuất', 'Đang Truy Xuất', '100000', 'VNMOBI', 1, '19/05/2022 - 20:22:47'),
(125, 1, 'Đang Truy Xuất', 'Đang Truy Xuất', '20000', 'VIETTEL', 2, '19/05/2022 - 20:43:18'),
(126, 8, 'Đang Truy Xuất', 'Đang Truy Xuất', '100000', 'VIETTEL', 2, '19/05/2022 - 23:22:21'),
(127, 8, 'Đang Truy Xuất', 'Đang Truy Xuất', '100000', 'VIETTEL', 2, '19/05/2022 - 23:22:31'),
(128, 8, 'Đang Truy Xuất', 'Đang Truy Xuất', '100000', 'VIETTEL', 2, '19/05/2022 - 23:22:56'),
(129, 8, 'Đang Truy Xuất', 'Đang Truy Xuất', '100000', 'VIETTEL', 2, '19/05/2022 - 23:23:06'),
(130, 8, '183882818381843', ' 100082326754343', '100000', 'VIETTEL', 1, '19/05/2022 - 23:23:53'),
(131, 537, 'Đang Xử Lí', 'Đang Xử Lí', '100000', 'MOBIFONE', 1, '15/09/2022 - 18:21:13'),
(132, 537, 'Đang Xử Lí', 'Đang Xử Lí', '100000', 'MOBIFONE', 3, '15/09/2022 - 18:21:16');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `napthe`
--

CREATE TABLE `napthe` (
  `id` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `loaithe` varchar(100) NOT NULL,
  `menhgia` bigint(20) NOT NULL,
  `serial` varchar(100) NOT NULL,
  `requestId` int(11) NOT NULL DEFAULT 0,
  `mathe` varchar(100) NOT NULL,
  `trangthai` bigint(20) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rutkc`
--

CREATE TABLE `rutkc` (
  `id` int(11) NOT NULL,
  `uid` int(255) NOT NULL,
  `trangthai` int(255) NOT NULL,
  `idgame` varchar(100) NOT NULL,
  `soluong` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `rutkc`
--

INSERT INTO `rutkc` (`id`, `uid`, `trangthai`, `idgame`, `soluong`, `time`) VALUES
(1, 537, 2, '0812665001', '280', '15/09/2022 - 18:21:48');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `taoweb`
--

CREATE TABLE `taoweb` (
  `id` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `domain` varchar(100) NOT NULL,
  `id_code` bigint(20) NOT NULL,
  `gia` bigint(20) NOT NULL,
  `time1` bigint(20) NOT NULL,
  `time2` varchar(100) NOT NULL,
  `thanhtoan` bigint(20) NOT NULL,
  `taikhoanadmin` varchar(100) NOT NULL,
  `matkhauadmin` varchar(100) NOT NULL,
  `trangthai` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `taoweb`
--

INSERT INTO `taoweb` (`id`, `uid`, `domain`, `id_code`, `gia`, `time1`, `time2`, `thanhtoan`, `taikhoanadmin`, `matkhauadmin`, `trangthai`) VALUES
(1, 537, 'tuanori.tk', 2, 120000, 1663240841, '15/09/2022 - 18:20:41', 1, 'admin72f13e9d7ff5', 'adminaf712ae91ac3', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `taikhoan` varchar(100) NOT NULL,
  `matkhau` varchar(100) NOT NULL,
  `tien` bigint(20) NOT NULL,
  `kimcuong` int(255) NOT NULL,
  `chucvu` bigint(20) NOT NULL,
  `qua` int(2) NOT NULL,
  `email` varchar(1000) DEFAULT NULL,
  `time` varchar(100) NOT NULL,
  `band` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `taikhoan`, `matkhau`, `tien`, `kimcuong`, `chucvu`, `qua`, `email`, `time`, `band`) VALUES
(537, 'tuanori', 'tuanori', 1640000, 0, 9, 2, 'tuanori@gmail.com', '15/09/2022 - 18:12:38', 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `danhmuc`
--
ALTER TABLE `danhmuc`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `danhmuc1`
--
ALTER TABLE `danhmuc1`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `danhsachcode`
--
ALTER TABLE `danhsachcode`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `goihost`
--
ALTER TABLE `goihost`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `hoatdong`
--
ALTER TABLE `hoatdong`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `lsmuahost`
--
ALTER TABLE `lsmuahost`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `magiamgia`
--
ALTER TABLE `magiamgia`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `muathe`
--
ALTER TABLE `muathe`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `napthe`
--
ALTER TABLE `napthe`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `rutkc`
--
ALTER TABLE `rutkc`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `taoweb`
--
ALTER TABLE `taoweb`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `danhmuc`
--
ALTER TABLE `danhmuc`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `danhmuc1`
--
ALTER TABLE `danhmuc1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `danhsachcode`
--
ALTER TABLE `danhsachcode`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `hoatdong`
--
ALTER TABLE `hoatdong`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `lsmuahost`
--
ALTER TABLE `lsmuahost`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `magiamgia`
--
ALTER TABLE `magiamgia`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `muathe`
--
ALTER TABLE `muathe`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT cho bảng `napthe`
--
ALTER TABLE `napthe`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rutkc`
--
ALTER TABLE `rutkc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `taoweb`
--
ALTER TABLE `taoweb`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=538;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
