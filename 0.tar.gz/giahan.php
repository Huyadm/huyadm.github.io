<?php
require_once __DIR__."/Client/include/config/database.php"; 

$giahan = $_GET['giahan'];
        $phat = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `lsmuahost` WHERE `id` = '$giahan'"));
if($phat['trangthai'] == '2'){
 die("<script>
    window.alert('Host của bạn đã bị xóa nên không thể thực hiện yêu cầu này!');
    window.location.href='/quan-ly-host?id=".$giahan."';
	</script>");
	exit;

}else
if($user['tien'] < $phat['sotien']){
 die("<script>
    window.alert('Bạn không đủ tiền để gia hạn!');
    window.location.href='/quan-ly-host?id=".$giahan."';
	</script>");
	exit;


}else{
    
$giahost =  $phat['sotien'];
mysqli_query($connect, "UPDATE user SET `tien` = `tien`-'".$giahost."' where `id` = '".$user['id']."' ") or exit(mysqli_error());
$giahan30day = 24*30*60*60;
mysqli_query($connect, "UPDATE lsmuahost SET `timehetdate` = `timehetdate`+'".$giahan30day."' where `id` = '".$giahan."' ") or exit(mysqli_error());
 die("<script>
    window.alert('Gia hạn thêm 30 ngày thành công!');
    window.location.href='/quan-ly-host?id=".$giahan."';
	</script>");
	exit;
}
?>
                                
