<?php
	//gọi route
	require_once __DIR__."/Client/include/core/route.php";
?>